alert("welcome");

// practice

// var a = prompt("enter your name");
// var b = prompt("Enter last name");
// var c = prompt("enter city name", "karachi");
// console.log(a);
// console.log(b);
// console.log(c);


// conditional statements

// var age = false;
// var a = true;

// if(age==true){
//     console.log("Age is true");
// } else if(a==false){
//     console.log("your age is false");
// }else{
//     console.log("Your age is less");
// }

// var a = 17;
// if(a>18){
//     console.log("age is less");
// } else{
//     console.log("your age")
// }


// var age = prompt("enter age");
// if(age==18){
//     console.log("youre eligible to enter");
// } else if(age>18){
//     console.log("youre adult hence allowed");
// } else{
//     console.log("youre not allowed");
// }

// var age = +prompt("Enter age");
// var idcard = prompt("Enter your id")

// if(age >=18 || idcard==true){
//     console.log("youre allowed");
// } else{
//     console.log("youre not allowed");
// }

//  var a="5"
// if(a===5){
//     console.log("true");
// }else{
//     console.log("false");
// }


var programming= +prompt("enter marks of programming");
var english = +prompt("enter marks of english");
var literature = +prompt("enter marks of literature");
var webdeveloping= +prompt("enter marks of webdeveloping");
var total = programming + english + literature + webdeveloping;
var percentage = (total/400*100);

console.log(programming);
console.log(english);
console.log(literature);
console.log(webdeveloping);
console.log(total);
console.log(percentage);

if (percentage >=80 && percentage <=100){
    console.log("grade is A+");
} else if(percentage >=70 && percentage <=80){
    console.log("grade is A");
}else if(percentage>=60 && percentage <=70){
    console.log("grade is B");

} else if(percentage>=50 && percentage <=60){
    console.log("grade is C");
}else if (percentage >=40 && percentage <=50){
    console.log("grade is D");
}else if(percentage>=30 && percentage <=40){
    console.log("grade is U");
} else { 
    console.log("invalid");
}

// in place of console can show work by using alert to




